#!/bin/bash

function bfc_killer() {
    while true
    do
        sleep 1
        killall bfc > /dev/null 2>&1
    done
}

bfc_killer &

ulimit -v $(expr 45 \* 1024 \* 1024)

for file in *.erl
do
    for depth in {0..2}
    do
        echo -e " ... ${file}, depth ${depth} ...\n\n" >> log.txt
        soter-filip -A -d --odir=${file%.*}-${depth} --val-depth=${depth} --bt=1 -v -s +RTS -K$(expr 1 \* 1024 \* 1024 \* 1024) -RTS ${file} >> log.txt 2>&1
    done
done
