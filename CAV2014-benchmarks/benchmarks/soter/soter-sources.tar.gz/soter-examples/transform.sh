cd ${HOME}/soter-examples/concdb-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|512,512" -o concdb__single_client_writes__depth_0.spec
cd ${HOME}/soter-examples/concdb-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|1310,1310" -o concdb__single_client_writes__depth_1.spec
cd ${HOME}/soter-examples/concdb-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|4315,4315" -o concdb__single_client_writes__depth_2.spec

cd ${HOME}/soter-examples/finite_leader-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|269,269" -o finite_leader__single_leader__depth_0.spec
cd ${HOME}/soter-examples/finite_leader-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|416,416" -o finite_leader__single_leader__depth_1.spec
cd ${HOME}/soter-examples/finite_leader-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|416,416" -o finite_leader__single_leader__depth_2.spec

cd ${HOME}/soter-examples/firewall-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|331" -o firewall__no_pred_called_with_zero__depth_0.spec
cd ${HOME}/soter-examples/firewall-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|739" -o firewall__no_pred_called_with_zero__depth_1.spec
cd ${HOME}/soter-examples/firewall-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|3849" -o firewall__no_pred_called_with_zero__depth_2.spec

cd ${HOME}/soter-examples/howait-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|201,202" -o howait__all_workers_finished_if_wait_over__depth_0.spec
cd ${HOME}/soter-examples/howait-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|688,689" -o howait__all_workers_finished_if_wait_over__depth_1.spec
cd ${HOME}/soter-examples/howait-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|1353,1354" -o howait__all_workers_finished_if_wait_over__depth_2.spec

cd ${HOME}/soter-examples/parikh-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|63" -o parikh__should_already_be_initialized__depth_0.spec
cd ${HOME}/soter-examples/parikh-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|71" -o parikh__should_already_be_initialized__depth_1.spec
cd ${HOME}/soter-examples/parikh-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|71" -o parikh__should_already_be_initialized__depth_2.spec

cd ${HOME}/soter-examples/pipe-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|200,200" -o pipe__single_message_in_mailbox__depth_0.spec
cd ${HOME}/soter-examples/pipe-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|1766,1766" -o pipe__single_message_in_mailbox__depth_1.spec
cd ${HOME}/soter-examples/pipe-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|1232,1232" -o pipe__single_message_in_mailbox__depth_2.spec

cd ${HOME}/soter-examples/reslock-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|341,341" -o reslock__critical__depth_0.spec
cd ${HOME}/soter-examples/reslock-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|554,554" -o reslock__critical__depth_1.spec
cd ${HOME}/soter-examples/reslock-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|767,767" -o reslock__critical__depth_2.spec

cd ${HOME}/soter-examples/reslockbeh-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|710,710" -o reslockbeh__critical__depth_0.spec
cd ${HOME}/soter-examples/reslockbeh-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|4421,4421" -o reslockbeh__critical__depth_1.spec
cd ${HOME}/soter-examples/reslockbeh-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|10131,10131" -o reslockbeh__critical__depth_2.spec

cd ${HOME}/soter-examples/ring-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|366,366" -o ring__single_message_in_mailbox__depth_0.spec
cd ${HOME}/soter-examples/ring-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|5565,5565" -o ring__single_message_in_mailbox__depth_1.spec
cd ${HOME}/soter-examples/ring-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|52061,52061" -o ring__single_message_in_mailbox__depth_2.spec

cd ${HOME}/soter-examples/safe_send-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|100" -o safe_send__sending_to_non-pid__depth_0.spec
cd ${HOME}/soter-examples/safe_send-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_1__depth_1.spec
ttstrans --input-file prop-2.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_2__depth_1.spec
ttstrans --input-file prop-3.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_3__depth_1.spec
ttstrans --input-file prop-4.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_4__depth_1.spec
cd ${HOME}/soter-examples/safe_send-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_1__depth_2.spec
ttstrans --input-file prop-2.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_2__depth_2.spec
ttstrans --input-file prop-3.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_3__depth_2.spec
ttstrans --input-file prop-4.bfc -w MIST -a "2|233" -o safe_send__sending_to_non-pid_4__depth_2.spec

cd ${HOME}/soter-examples/sieve-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|238,238" -o sieve__single_message_in_counter_mailbox__depth_0.spec
cd ${HOME}/soter-examples/tmp/sieve-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|238,238" -o sieve__single_message_in_counter_mailbox__depth_0.spec
ttstrans --input-file prop-2.bfc -w MIST -a "2|238,238" -o sieve__single_message_in_filter_mailbox__depth_0.spec
ttstrans --input-file prop-3.bfc -w MIST -a "2|238,238" -o sieve__single_message_in_sieve_mailbox__depth_0.spec
cd ${HOME}/soter-examples/sieve-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|1211,1211" -o sieve__single_message_in_counter_mailbox__depth_1.spec
cd ${HOME}/soter-examples/sieve-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|2255,2255" -o sieve__single_message_in_counter_mailbox__depth_2.spec

cd ${HOME}/soter-examples/state_factory-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|526,526" -o state_factory__single_message_in_mailbox__depth_0.spec
ttstrans --input-file prop-2.bfc -w MIST -a "2|526,527" -o state_factory__after_receive_if_no_mail__depth_0.spec
cd ${HOME}/soter-examples/state_factory-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|20566,20566" -o state_factory__single_message_in_mailbox__depth_1.spec

cd ${HOME}/soter-examples/stutter-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|78" -o stutter__we_abhorr_as__depth_0.spec
cd ${HOME}/soter-examples/stutter-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|96" -o stutter__we_abhorr_as__depth_1.spec
cd ${HOME}/soter-examples/stutter-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|96" -o stutter__we_abhorr_as__depth_2.spec

cd ${HOME}/soter-examples/unsafe_send-0
ttstrans --input-file prop-1.bfc -w MIST -a "2|28" -o unsafe_send__sending_to_non-pid__depth_0.spec
cd ${HOME}/soter-examples/unsafe_send-1
ttstrans --input-file prop-1.bfc -w MIST -a "2|28" -o unsafe_send__sending_to_non-pid__depth_1.spec
cd ${HOME}/soter-examples/unsafe_send-2
ttstrans --input-file prop-1.bfc -w MIST -a "2|28" -o unsafe_send__sending_to_non-pid__depth_2.spec
